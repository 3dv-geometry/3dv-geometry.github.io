# Mask Image

source: `{{ page.path }}`